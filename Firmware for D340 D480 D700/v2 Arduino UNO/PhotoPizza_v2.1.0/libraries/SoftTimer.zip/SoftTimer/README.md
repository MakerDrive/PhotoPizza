# SoftTimer
Arduino non-blocking timer/delay, based on https://code.google.com/p/arduino-softtimer/
 
